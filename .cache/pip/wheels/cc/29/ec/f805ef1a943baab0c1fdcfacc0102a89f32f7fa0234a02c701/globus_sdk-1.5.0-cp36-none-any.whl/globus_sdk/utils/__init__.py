from globus_sdk.utils.string_handling import safe_b64encode


__all__ = [
    'safe_b64encode'
]
