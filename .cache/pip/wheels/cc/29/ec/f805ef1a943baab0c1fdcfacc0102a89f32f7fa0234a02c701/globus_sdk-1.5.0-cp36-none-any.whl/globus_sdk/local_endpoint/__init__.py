from globus_sdk.local_endpoint.personal import LocalGlobusConnectPersonal

__all__ = ('LocalGlobusConnectPersonal',)
