
VERSION = (1, 2, 2)
__version__ = ''.join(['-.'[type(x) == int]+str(x) for x in VERSION])[1:]


